#!/system/bin/sh
# Copyright© 2011 redmaner
# Backup app_proces and system_server


if [ -d /sdcard/engengis/backup ]; then
    echo "Backup folder already exists"
else
    mkdir /sdcard/engengis/backup
fi;
if [ -d /sdcard/engengis/backup/fugu ]; then
    echo "Fugu folder already exists"
else
    mkdir /sdcard/engengis/backup/fugu
fi;
if [ -e /sdcard/engengis/backup/fugu/app_process ]; then
    echo "There is already a backup off app_process"
else
    cp /system/bin/app_process /sdcard/engengis/backup/fugu/app_process
fi;
if [ -e /sdcard/engengis/backup/fugu/system_server ]; then
    echo "There is already a backup off system_server"
else
    cp /system/bin/system_server /sdcard/engengis/backup/fugu/system_server
fi;
